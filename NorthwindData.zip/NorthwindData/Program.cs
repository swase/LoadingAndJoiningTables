﻿using System;
using System.Linq;
namespace NorthwindData
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new NorthwindContext())
            {

                


            }
        }
    }
}
